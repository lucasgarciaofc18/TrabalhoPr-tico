document.querySelectorAll('.voltarAoTopo').forEach(img => {
    img.addEventListener('click', function () {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});
